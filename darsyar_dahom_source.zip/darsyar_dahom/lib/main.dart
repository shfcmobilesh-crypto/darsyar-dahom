import 'package:flutter/material.dart';

void main() => runApp(const DarsyarApp());

const bg = Color(0xFF090B18);
const panel = Color(0xFF15182B);
const purple = Color(0xFF9B7BFF);
const blue = Color(0xFF4CD7FF);

class DarsyarApp extends StatelessWidget {
  const DarsyarApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'درس‌یار دهم',
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
      textTheme: ThemeData.dark().textTheme.apply(fontFamily: 'Roboto'),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final subjects = const [
    ('زیست‌شناسی', 'فصل ۱ • دنیای زنده', Icons.biotech_rounded, Color(0xFF52E0B5)),
    ('شیمی', 'فصل ۱ • کیهان، زادگاه الفبای هستی', Icons.science_rounded, Color(0xFF64C8FF)),
    ('فیزیک', 'فصل ۱ • فیزیک و اندازه‌گیری', Icons.bolt_rounded, Color(0xFFFFC66D)),
    ('ریاضی', 'فصل ۱ • مجموعه، الگو و دنباله', Icons.functions_rounded, Color(0xFFB69BFF)),
    ('فارسی', 'درس ۱ • چشمه و سنگ', Icons.menu_book_rounded, Color(0xFFFF8EB6)),
    ('عربی', 'درس ۱ • مُراجَعَةُ المَکتَبَة', Icons.translate_rounded, Color(0xFF7CE6E6)),
  ];
  @override Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: [
        _home(), _simplePage('درس‌های من', 'درس‌ها و جزوه‌های ذخیره‌شده اینجا قرار می‌گیرند.', Icons.bookmarks_rounded),
        _simplePage('آزمون‌ها', 'آزمون‌های فصل‌به‌فصل و ثبت نتیجه در نسخه بعدی اضافه می‌شود.', Icons.quiz_rounded),
        _simplePage('پروفایل', 'دانش‌آموز پایه دهم تجربی', Icons.person_rounded),
      ])),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF111426), indicatorColor: purple.withOpacity(.2),
        selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.menu_book_rounded), label: 'درس‌ها'),
          NavigationDestination(icon: Icon(Icons.quiz_rounded), label: 'آزمون'),
          NavigationDestination(icon: Icon(Icons.person_rounded), label: 'پروفایل'),
        ],
      ),
    ));
  }
  Widget _home() => ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 28), children: [
    Row(children: [
      Container(width: 48, height: 48, decoration: BoxDecoration(gradient: const LinearGradient(colors: [purple, blue]), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.auto_awesome_rounded, color: bg, size: 28)),
      const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('درس‌یار دهم', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('پایه دهم • رشته علوم تجربی', style: TextStyle(color: Colors.white60, fontSize: 12))])),
      IconButton(onPressed: () => _notice('اعلان‌ها در نسخه آنلاین فعال می‌شوند.'), icon: const Icon(Icons.notifications_none_rounded, color: blue, size: 27)),
    ]),
    const SizedBox(height: 22),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF32236B), Color(0xFF17284C), Color(0xFF14172B)]), borderRadius: BorderRadius.circular(24), border: Border.all(color: purple.withOpacity(.45))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('وقتشه بدرخشی ✨', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      const Text('قدم‌های کوچک امروز، نتیجه‌های بزرگ فردا.', style: TextStyle(color: Colors.white70)), const SizedBox(height: 18),
      Row(children: [const Icon(Icons.local_fire_department_rounded, color: Color(0xFFFFB45C)), const SizedBox(width: 6), const Text('برنامه امروزت رو شروع کن', style: TextStyle(fontWeight: FontWeight.w600)), const Spacer(), Icon(Icons.arrow_back_rounded, color: blue)]),
    ])),
    const SizedBox(height: 25),
    Row(children: [const Text('درس‌ها', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const Spacer(), Text('پایه دهم تجربی', style: TextStyle(color: blue, fontSize: 12))]),
    const SizedBox(height: 13),
    GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: subjects.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.12), itemBuilder: (context, i) {
      final s = subjects[i]; return InkWell(onTap: () => _subject(s.$1, s.$2), borderRadius: BorderRadius.circular(20), child: Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: s.$4.withOpacity(.28))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: s.$4.withOpacity(.14), borderRadius: BorderRadius.circular(14)), child: Icon(s.$3, color: s.$4, size: 25)), const Spacer(), Text(s.$1, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 5), Text(s.$2, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 10, height: 1.5))])));
    }),
    const SizedBox(height: 22),
    const Text('دسترسی سریع', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
    _quick(Icons.calendar_month_rounded, 'برنامه‌ریزی درسی', 'برای مطالعه‌ات برنامه بچین', blue, () => _notice('بخش برنامه‌ریزی در نسخه بعدی تکمیل می‌شود.')),
    const SizedBox(height: 10), _quick(Icons.insights_rounded, 'پیشرفت من', 'نتایج و روند مطالعه', purple, () => _notice('برای نمایش آمار، ابتدا آزمون‌ها را فعال می‌کنیم.')),
  ]);
  Widget _quick(IconData icon, String title, String subtitle, Color c, VoidCallback action) => InkWell(onTap: action, borderRadius: BorderRadius.circular(16), child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)), child: Row(children: [Icon(icon, color: c, size: 27), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12))])), const Icon(Icons.chevron_left_rounded, color: Colors.white54)])));
  Widget _simplePage(String title, String desc, IconData icon) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 60, color: purple), const SizedBox(height: 18), Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), const SizedBox(height: 10), Text(desc, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, height: 1.7))])));
  void _subject(String title, String subtitle) => showModalBottomSheet(context: context, backgroundColor: panel, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(color: blue)), const SizedBox(height: 18), const ListTile(leading: Icon(Icons.picture_as_pdf_rounded, color: purple), title: Text('جزوه‌ها'), subtitle: Text('محتوا پس از اتصال پنل مدیر منتشر می‌شود')), const ListTile(leading: Icon(Icons.play_circle_outline_rounded, color: blue), title: Text('آموزش ویدیویی'), subtitle: Text('به‌زودی')), const SizedBox(height: 12)]))));
  void _notice(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s), behavior: SnackBarBehavior.floating, backgroundColor: const Color(0xFF292443)));
}
